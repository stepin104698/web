var Laptop = ["HP","Lenovo","Dell","Applie","Asus","Samsung","Acer"];
var Mobile=["Realme","Redmi","Motorola","Vivo","Oppo","Samsung","One Plus"];
var TV=["Toshiba","Onida","Lenovo","Xiaomi","Samsung","LG"];